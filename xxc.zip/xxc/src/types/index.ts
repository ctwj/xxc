export interface Option {
  label: string;
  value: string;
  icon?: React.ComponentType<{ className?: string }>;
  withCount?: boolean;
}

export type ContentType = 
  | 'text' 
  | 'image' 
  | 'video' 
  | 'image-text' 
  | 'video-text'
  | 'images'           // 多张图片（无文字）
  | 'images-text'      // 多张图片 + 文字
  | 'images-video-text' // 多张图片 + 视频 + 文字
  | 'long-text';       // 长文本;

export interface InfoCardData {
  id: string;
  type: ContentType;
  title?: string;
  content?: string;
  mediaUrl?: string;      // 单个媒体URL（向后兼容）
  mediaUrls?: string[];   // 多个图片URL
  videoUrl?: string;      // 视频URL（用于混合类型）
  coverUrl?: string;      // 视频封面
  tag: string;
  publishTime: string;
  isNew?: boolean;
  isFavorited?: boolean;
}
