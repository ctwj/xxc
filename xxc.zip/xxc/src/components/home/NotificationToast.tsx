import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Bell } from 'lucide-react';

interface NotificationToastProps {
  message: string;
  isVisible: boolean;
  onClose: () => void;
  onClick?: () => void;
}

export const NotificationToast: React.FC<NotificationToastProps> = ({ 
  message, 
  isVisible, 
  onClose,
  onClick 
}) => {
  useEffect(() => {
    if (isVisible) {
      const timer = setTimeout(() => {
        onClose();
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [isVisible, onClose]);

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ y: -100, x: '-50%', opacity: 0 }}
          animate={{ y: 0, x: '-50%', opacity: 1 }}
          exit={{ y: -100, x: '-50%', opacity: 0 }}
          transition={{ type: 'spring', damping: 20, stiffness: 300 }}
          className="fixed top-8 left-1/2 z-[100] cursor-pointer"
          onClick={onClick}
        >
          <div className="flex items-center gap-3 px-6 py-3 bg-white text-black rounded-full shadow-2xl ring-1 ring-black/5 active:scale-95 transition-transform">
            <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary">
              <Bell size={16} />
            </div>
            <span className="text-sm font-semibold tracking-tight">{message}</span>
            <div className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};