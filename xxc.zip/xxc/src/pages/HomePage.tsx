import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { User, RefreshCcw, LogOut, LogIn, ChevronLeft, ChevronRight, Sun, Moon } from 'lucide-react';
import { CardStack } from '@/components/home/CardStack';
import { ActionBar } from '@/components/home/ActionBar';
import { NotificationToast } from '@/components/home/NotificationToast';
import { MOCK_CARDS } from '@/data/mockData';
import { useFavorites } from '@/hooks/useFavorites';
import { useAuth } from '@/contexts/AuthContext';
import { useTheme } from '@/contexts/ThemeContext';
import { InfoCardData } from '@/types';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'sonner';

export const HomePage: React.FC = () => {
  const navigate = useNavigate();
  const { isFavorited, toggleFavorite } = useFavorites();
  const { user, signOut } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [cards, setCards] = useState<InfoCardData[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [showNotification, setShowNotification] = useState(false);
  const [newContentCount, setNewContentCount] = useState(0);
  
  // 边界状态：-1 表示"没有更新的消息"，cards.length 表示"需要登录"
  const isAtNewerBoundary = currentIndex === -1;
  const isAtOlderBoundary = currentIndex === cards.length;

  // 过滤和排序卡片：未登录用户只能看两天内的消息，按时间倒序排列（最新的在前）
  useEffect(() => {
    const now = new Date();
    const twoDaysAgo = new Date(now.getTime() - 2 * 24 * 60 * 60 * 1000);
    
    let filteredCards = MOCK_CARDS;
    
    if (!user) {
      // 未登录用户只能看两天内的消息
      filteredCards = MOCK_CARDS.filter(card => {
        const cardDate = new Date(card.publishTime);
        return cardDate >= twoDaysAgo;
      });
    }
    
    // 按时间倒序排列（最新的在前）
    const sortedCards = [...filteredCards].sort((a, b) => {
      return new Date(b.publishTime).getTime() - new Date(a.publishTime).getTime();
    });
    
    setCards(sortedCards);
    setCurrentIndex(0); // 重置到第一张（最新的）
  }, [user]);

  // 模拟新消息提醒
  useEffect(() => {
    const hasNew = cards.filter(c => c.isNew).length;
    if (hasNew > 0) {
      setNewContentCount(hasNew);
      const timer = setTimeout(() => {
        setShowNotification(true);
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [cards]);

  // 检查登录状态的操作处理
  useEffect(() => {
    // 移除这个 effect，边界状态由 currentIndex 直接控制
  }, []);

  const handleSwipe = (id: string, direction: 'left' | 'right') => {
    console.log(`Swiped ${id} to ${direction}`);
    // 滑动不再改变索引，由按钮控制
  };

  const handleRefresh = () => {
    // 重新加载数据并排序
    const now = new Date();
    const twoDaysAgo = new Date(now.getTime() - 2 * 24 * 60 * 60 * 1000);
    
    let filteredCards = MOCK_CARDS;
    
    if (!user) {
      filteredCards = MOCK_CARDS.filter(card => {
        const cardDate = new Date(card.publishTime);
        return cardDate >= twoDaysAgo;
      });
    }
    
    // 按时间倒序排列（最新的在前）
    const sortedCards = [...filteredCards].sort((a, b) => {
      return new Date(b.publishTime).getTime() - new Date(a.publishTime).getTime();
    });
    
    setCards(sortedCards);
    setCurrentIndex(0);
    setShowNotification(false);
  };

  const handleSignOut = async () => {
    await signOut();
    toast.success('已退出登录');
  };

  // 左右按钮控制
  const handleViewOlder = () => {
    // 向左 = 查看更早的消息（索引+1）
    if (isAtNewerBoundary) {
      // 从"没有更新"状态返回到第一张（最新的）
      setCurrentIndex(0);
      return;
    }
    
    if (currentIndex < cards.length - 1) {
      setCurrentIndex(prev => prev + 1);
    } else if (currentIndex === cards.length - 1) {
      // 到达最后一张，继续向左进入"需要登录"状态
      setCurrentIndex(cards.length);
    }
  };

  const handleViewNewer = () => {
    // 向右 = 查看更新的消息（索引-1）
    if (isAtOlderBoundary) {
      // 从"需要登录"状态返回到最后一张
      setCurrentIndex(cards.length - 1);
      return;
    }
    
    if (currentIndex > 0) {
      setCurrentIndex(prev => prev - 1);
    } else if (currentIndex === 0) {
      // 到达第一张，继续向右进入"没有更新"状态
      setCurrentIndex(-1);
    }
  };

  // 检查登录状态的操作处理
  const handleLike = () => {
    handleViewNewer();
  };

  const handleDislike = () => {
    handleViewOlder();
  };

  const handleFavorite = () => {
    if (!user) {
      toast.error('请先登录');
      navigate('/login');
      return;
    }
    if (currentCard) {
      toggleFavorite(currentCard);
    }
  };

  const handleShareCard = (card: InfoCardData) => {
    // 生成分享文本
    const shareText = `${card.title || '精彩内容'}\n\n${card.content || ''}\n\n来自每日信息差`;
    
    // 尝试使用 Web Share API
    if (navigator.share) {
      navigator.share({
        title: card.title || '每日信息差',
        text: shareText,
        url: window.location.href,
      }).catch(() => {
        // 用户取消分享
      });
    } else {
      // 降级方案：复制到剪贴板
      navigator.clipboard.writeText(shareText).then(() => {
        toast.success('内容已复制到剪贴板');
      }).catch(() => {
        toast.error('分享失败');
      });
    }
  };

  const currentCard = cards[currentIndex];

  return (
    <div className="relative h-screen w-screen bg-background overflow-hidden flex flex-col">
      {/* 顶部极简状态栏 */}
      <header className="fixed top-0 left-0 right-0 z-50 px-8 py-10 flex items-center justify-between pointer-events-none">
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="text-xl font-bold tracking-tight text-foreground pointer-events-auto"
        >
          每日信息差
        </motion.div>
        <div className="flex items-center gap-3 pointer-events-auto">
          {/* 主题切换按钮 */}
          <motion.button
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={toggleTheme}
            className="p-3 bg-foreground/10 backdrop-blur-md rounded-full text-foreground hover:bg-foreground/20 transition-all border border-foreground/10 active:scale-90"
            title={theme === 'dark' ? '切换到亮色模式' : '切换到暗黑模式'}
          >
            {theme === 'dark' ? <Sun size={22} /> : <Moon size={22} />}
          </motion.button>

          {user ? (
            <>
              <motion.button 
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                onClick={() => navigate('/favorites')}
                className="p-3 bg-foreground/10 backdrop-blur-md rounded-full text-foreground hover:bg-foreground/20 transition-all border border-foreground/10 active:scale-90"
              >
                <User size={22} />
              </motion.button>
              <motion.button 
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.05 }}
                onClick={handleSignOut}
                className="p-3 bg-foreground/10 backdrop-blur-md rounded-full text-foreground hover:bg-destructive/80 transition-all border border-foreground/10 active:scale-90"
                title="退出登录"
              >
                <LogOut size={22} />
              </motion.button>
            </>
          ) : (
            <motion.button 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              onClick={() => navigate('/login')}
              className="px-5 py-2.5 bg-primary backdrop-blur-md rounded-full text-primary-foreground hover:bg-primary/90 transition-all border border-primary/20 active:scale-90 font-semibold text-sm flex items-center gap-2"
            >
              <LogIn size={18} />
              登录
            </motion.button>
          )}
        </div>
      </header>

      {/* 核心卡片堆叠 */}
      <main className="flex-1 flex items-center justify-center relative">
        {/* 没有更新的消息提示 */}
        {isAtNewerBoundary && (
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="absolute inset-0 flex items-center justify-center z-30"
          >
            <div className="glass-card rounded-[20px] p-12 max-w-md mx-4 text-center">
              <h2 className="text-2xl font-bold mb-4 text-foreground">当前没有更新的消息</h2>
              <p className="text-foreground/60 mb-8 leading-relaxed">
                您已经浏览到最新的内容了。请等待消息更新，或者浏览历史消息。
              </p>
              <div className="flex gap-4 justify-center">
                <button
                  onClick={handleViewOlder}
                  className="px-8 py-3 bg-primary text-primary-foreground rounded-full font-semibold hover:bg-primary/90 transition-all active:scale-95"
                >
                  浏览历史消息
                </button>
              </div>
            </div>
          </motion.div>
        )}

        {/* 需要登录提示 */}
        {isAtOlderBoundary && (
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="absolute inset-0 flex items-center justify-center z-30"
          >
            <div className="glass-card rounded-[20px] p-12 max-w-md mx-4 text-center">
              <h2 className="text-2xl font-bold mb-4 text-foreground">登录后可以查看更多信息</h2>
              <p className="text-foreground/60 mb-8 leading-relaxed">
                您已浏览完最近两天的内容。登录后可以查看更多历史信息，并享受收藏、个性化推荐等功能。
              </p>
              <div className="flex gap-4 justify-center">
                <button
                  onClick={() => navigate('/login')}
                  className="px-8 py-3 bg-primary text-primary-foreground rounded-full font-semibold hover:bg-primary/90 transition-all active:scale-95"
                >
                  立即登录
                </button>
                <button
                  onClick={handleViewNewer}
                  className="px-8 py-3 bg-foreground/10 text-foreground rounded-full font-semibold hover:bg-foreground/20 transition-all active:scale-95"
                >
                  返回最后一条
                </button>
              </div>
            </div>
          </motion.div>
        )}

        {/* 正常卡片显示 */}
        {!isAtNewerBoundary && !isAtOlderBoundary && (
          <CardStack 
            cards={cards}
            currentIndex={currentIndex}
            onSwipe={handleSwipe}
            onFavorite={toggleFavorite}
            isFavorited={isFavorited}
            onRefresh={handleRefresh}
            onShare={handleShareCard}
          />
        )}

        {/* 左右箭头按钮 - 仅桌面端显示 */}
        {cards.length > 0 && (
          <>
            {/* 左箭头：在"没有更新"状态下也显示 */}
            {!isAtOlderBoundary && (
              <motion.button
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 0.6, x: 0 }}
                whileHover={{ opacity: 1, scale: 1.1 }}
                onClick={handleDislike}
                className="hidden md:flex absolute left-8 top-1/2 -translate-y-1/2 z-40 w-14 h-14 items-center justify-center bg-foreground/10 backdrop-blur-md rounded-full text-foreground hover:bg-foreground/20 transition-all border border-foreground/10 active:scale-90"
                title="查看更早的消息"
              >
                <ChevronLeft size={28} />
              </motion.button>
            )}

            {/* 右箭头：在"需要登录"状态下显示，在"没有更新"状态下隐藏 */}
            {!isAtNewerBoundary && (
              <motion.button
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 0.6, x: 0 }}
                whileHover={{ opacity: 1, scale: 1.1 }}
                onClick={handleLike}
                className="hidden md:flex absolute right-8 top-1/2 -translate-y-1/2 z-40 w-14 h-14 items-center justify-center bg-foreground/10 backdrop-blur-md rounded-full text-foreground hover:bg-foreground/20 transition-all border border-foreground/10 active:scale-90"
                title="查看更新的消息"
              >
                <ChevronRight size={28} />
              </motion.button>
            )}
          </>
        )}
      </main>

      {/* 底部操作栏 - 仅当有卡片且不在边界状态时显示 */}
      <AnimatePresence>
        {cards.length > 0 && !isAtNewerBoundary && !isAtOlderBoundary && (
          <motion.div
            initial={{ y: 100, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 100, opacity: 0 }}
            transition={{ delay: 0.2 }}
          >
            <ActionBar 
              onLike={handleLike}
              onDislike={handleDislike}
              onFavorite={handleFavorite}
              isFavorited={currentCard ? isFavorited(currentCard.id) : false}
            />
          </motion.div>
        )}
      </AnimatePresence>

      {/* 新内容提醒 */}
      <NotificationToast 
        isVisible={showNotification}
        message={`有 ${newContentCount} 条新内容，点击刷新`}
        onClose={() => setShowNotification(false)}
        onClick={handleRefresh}
      />
      
      {/* 全局背景动态色块 (微妙) */}
      <div className="absolute inset-0 z-[-1] overflow-hidden pointer-events-none opacity-30">
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-primary/20 blur-[120px] rounded-full animate-pulse" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-accent/10 blur-[120px] rounded-full animate-pulse delay-1000" />
      </div>
    </div>
  );
};