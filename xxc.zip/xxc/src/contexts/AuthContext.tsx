import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import { toast } from 'sonner';

// Mock User 类型
interface MockUser {
  id: string;
  email: string;
  created_at: string;
  invite_code?: string;
}

// Mock Profile 类型
interface Profile {
  id: string;
  email: string;
  invite_code?: string;
}

interface AuthContextType {
  user: MockUser | null;
  profile: Profile | null;
  loading: boolean;
  signInWithEmail: (email: string, password: string) => Promise<{ error: Error | null }>;
  signUpWithEmail: (email: string, password: string, inviteCode?: string) => Promise<{ error: Error | null }>;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// LocalStorage 键名
const USERS_KEY = 'mock_users';
const CURRENT_USER_KEY = 'mock_current_user';

// 获取所有用户
function getAllUsers(): Record<string, { password: string; user: MockUser }> {
  const data = localStorage.getItem(USERS_KEY);
  return data ? JSON.parse(data) : {};
}

// 保存所有用户
function saveAllUsers(users: Record<string, { password: string; user: MockUser }>) {
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
}

// 获取当前用户
function getCurrentUser(): MockUser | null {
  const data = localStorage.getItem(CURRENT_USER_KEY);
  return data ? JSON.parse(data) : null;
}

// 保存当前用户
function saveCurrentUser(user: MockUser | null) {
  if (user) {
    localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user));
  } else {
    localStorage.removeItem(CURRENT_USER_KEY);
  }
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<MockUser | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  const refreshProfile = async () => {
    if (!user) {
      setProfile(null);
      return;
    }

    // Mock profile 数据
    setProfile({
      id: user.id,
      email: user.email,
      invite_code: user.invite_code,
    });
  };

  useEffect(() => {
    // 初始化时从 localStorage 加载当前用户
    const currentUser = getCurrentUser();
    setUser(currentUser);
    if (currentUser) {
      setProfile({
        id: currentUser.id,
        email: currentUser.email,
        invite_code: currentUser.invite_code,
      });
    }
    setLoading(false);
  }, []);

  const signInWithEmail = async (email: string, password: string) => {
    try {
      // 模拟网络延迟
      await new Promise(resolve => setTimeout(resolve, 500));

      const users = getAllUsers();
      const userRecord = users[email];

      if (!userRecord) {
        throw new Error('邮箱未注册');
      }

      if (userRecord.password !== password) {
        throw new Error('密码错误');
      }

      const loggedInUser = userRecord.user;
      setUser(loggedInUser);
      saveCurrentUser(loggedInUser);
      
      setProfile({
        id: loggedInUser.id,
        email: loggedInUser.email,
        invite_code: loggedInUser.invite_code,
      });

      return { error: null };
    } catch (error) {
      return { error: error as Error };
    }
  };

  const signUpWithEmail = async (email: string, password: string, inviteCode?: string) => {
    try {
      // 模拟网络延迟
      await new Promise(resolve => setTimeout(resolve, 500));

      const users = getAllUsers();

      if (users[email]) {
        throw new Error('邮箱已被注册');
      }

      const newUser: MockUser = {
        id: `user_${Date.now()}`,
        email,
        created_at: new Date().toISOString(),
        invite_code: inviteCode,
      };

      users[email] = {
        password,
        user: newUser,
      };

      saveAllUsers(users);

      return { error: null };
    } catch (error) {
      return { error: error as Error };
    }
  };

  const signOut = async () => {
    setUser(null);
    setProfile(null);
    saveCurrentUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, profile, loading, signInWithEmail, signUpWithEmail, signOut, refreshProfile }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
