import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Mail, Lock, ArrowLeft, Loader2, CheckCircle2, Gift, ChevronDown } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';

export const RegisterPage: React.FC = () => {
  const navigate = useNavigate();
  const { signUpWithEmail, signInWithEmail } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [inviteCode, setInviteCode] = useState('');
  const [showInviteCode, setShowInviteCode] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email.trim() || !password.trim() || !confirmPassword.trim()) {
      toast.error('请填写所有必填字段');
      return;
    }

    // 验证邮箱格式
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      toast.error('请输入有效的邮箱地址');
      return;
    }

    // 验证密码长度
    if (password.length < 6) {
      toast.error('密码长度至少为 6 个字符');
      return;
    }

    // 验证密码一致性
    if (password !== confirmPassword) {
      toast.error('两次输入的密码不一致');
      return;
    }

    setLoading(true);
    const { error } = await signUpWithEmail(email, password, inviteCode || undefined);

    if (error) {
      setLoading(false);
      toast.error('注册失败：' + error.message);
    } else {
      // 注册成功后自动登录
      const { error: loginError } = await signInWithEmail(email, password);
      setLoading(false);
      
      if (loginError) {
        toast.success('注册成功，请登录');
        navigate('/login');
      } else {
        toast.success('注册成功，欢迎使用每日信息差');
        navigate('/');
      }
    }
  };

  return (
    <div className="relative min-h-screen w-screen bg-background overflow-hidden flex items-center justify-center py-12">
      {/* 背景动态色块 */}
      <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none opacity-30">
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-primary/20 blur-[120px] rounded-full animate-pulse" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-accent/10 blur-[120px] rounded-full animate-pulse delay-1000" />
      </div>

      {/* 返回按钮 */}
      <button 
        onClick={() => navigate('/')}
        className="fixed top-8 left-8 z-50 p-3 bg-white/10 backdrop-blur-md rounded-full text-white hover:bg-white/20 transition-all border border-white/10 active:scale-90"
      >
        <ArrowLeft size={22} />
      </button>

      {/* 注册表单卡片 */}
      <motion.div
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        transition={{ type: 'spring', damping: 20, stiffness: 300 }}
        className="relative z-10 w-full max-w-md mx-4"
      >
        <div className="glass-card rounded-[20px] p-10 shadow-2xl">
          {/* 标题 */}
          <div className="text-center mb-10">
            <h1 className="text-3xl font-bold mb-2 gradient-text">创建账号</h1>
            <p className="text-foreground/60 text-sm">加入每日信息差，发现更多精彩内容</p>
          </div>

          {/* 表单 */}
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="email" className="text-foreground/80 text-sm font-medium">
                邮箱地址
              </Label>
              <div className="relative">
                <Mail size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-foreground/40" />
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="your@email.com"
                  className="pl-12 h-12 bg-background/50 border-white/10 rounded-full text-foreground placeholder:text-foreground/30 focus:border-primary transition-all"
                  disabled={loading}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="password" className="text-foreground/80 text-sm font-medium">
                密码
              </Label>
              <div className="relative">
                <Lock size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-foreground/40" />
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="至少6个字符"
                  className="pl-12 h-12 bg-background/50 border-white/10 rounded-full text-foreground placeholder:text-foreground/30 focus:border-primary transition-all"
                  disabled={loading}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="confirmPassword" className="text-foreground/80 text-sm font-medium">
                确认密码
              </Label>
              <div className="relative">
                <CheckCircle2 size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-foreground/40" />
                <Input
                  id="confirmPassword"
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="再次输入密码"
                  className="pl-12 h-12 bg-background/50 border-white/10 rounded-full text-foreground placeholder:text-foreground/30 focus:border-primary transition-all"
                  disabled={loading}
                />
              </div>
            </div>

            {/* 邀请码展开区域 */}
            <div className="space-y-2">
              <button
                type="button"
                onClick={() => setShowInviteCode(!showInviteCode)}
                className="flex items-center gap-2 text-foreground/60 hover:text-foreground transition-colors text-sm font-medium"
              >
                <Gift size={16} />
                <span>有邀请码？</span>
                <ChevronDown 
                  size={16} 
                  className={`transition-transform duration-300 ${showInviteCode ? 'rotate-180' : ''}`} 
                />
              </button>
              
              <AnimatePresence>
                {showInviteCode && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                    className="overflow-hidden"
                  >
                    <div className="relative pt-2">
                      <Gift size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-accent" />
                      <Input
                        id="inviteCode"
                        type="text"
                        value={inviteCode}
                        onChange={(e) => setInviteCode(e.target.value)}
                        placeholder="输入邀请码（可选）"
                        className="pl-12 h-12 bg-background/50 border-accent/20 rounded-full text-foreground placeholder:text-foreground/30 focus:border-accent transition-all"
                        disabled={loading}
                      />
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            <Button
              type="submit"
              disabled={loading}
              className="w-full h-12 rounded-full bg-primary hover:bg-primary/90 text-white font-bold shadow-lg shadow-primary/30 transition-all active:scale-95"
            >
              {loading ? (
                <>
                  <Loader2 size={20} className="animate-spin mr-2" />
                  注册中...
                </>
              ) : (
                '注册'
              )}
            </Button>
          </form>

          {/* 登录链接 */}
          <div className="mt-8 text-center">
            <p className="text-foreground/60 text-sm">
              已有账号？{' '}
              <Link 
                to="/login" 
                className="text-primary font-semibold hover:underline transition-all"
              >
                立即登录
              </Link>
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
};
