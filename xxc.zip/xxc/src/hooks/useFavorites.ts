import { useState, useEffect, useCallback } from 'react';
import { InfoCardData } from '../types';

const FAVORITES_KEY = 'daily_diff_favorites';

export function useFavorites() {
  const [favorites, setFavorites] = useState<InfoCardData[]>([]);

  // 从 localStorage 加载收藏
  useEffect(() => {
    const saved = localStorage.getItem(FAVORITES_KEY);
    if (saved) {
      try {
        setFavorites(JSON.parse(saved));
      } catch (e) {
        console.error('Failed to parse favorites:', e);
      }
    }
  }, []);

  // 保存收藏到 localStorage
  useEffect(() => {
    localStorage.setItem(FAVORITES_KEY, JSON.stringify(favorites));
  }, [favorites]);

  const toggleFavorite = useCallback((card: InfoCardData) => {
    setFavorites((prev) => {
      const isExist = prev.some((item) => item.id === card.id);
      if (isExist) {
        return prev.filter((item) => item.id !== card.id);
      } else {
        return [...prev, { ...card, isFavorited: true }];
      }
    });
  }, []);

  const isFavorited = useCallback((id: string) => {
    return favorites.some((item) => item.id === id);
  }, [favorites]);

  return { favorites, toggleFavorite, isFavorited };
}
